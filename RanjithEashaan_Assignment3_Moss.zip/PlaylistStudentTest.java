import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PlaylistStudentTest {

	private Playlist playlist;
	private Song song1;
	private Song song2;

	@Before
	public void setUp() {
		playlist = new Playlist("My Playlist");
		song1 = new Song("Song A", "Artist A");
		song2 = new Song("Song B", "Artist B");
	}

	@Test
	public void testGetName() {
		assertEquals("My Playlist", playlist.getName());
	}

	@Test
	public void testAddSong() {
		assertTrue(playlist.addSong(song1));
		assertEquals(1, playlist.getSize());
	}

	@Test
	public void testIsEmpty() {
		assertTrue(playlist.isEmpty());
		playlist.addSong(song1);
		assertFalse(playlist.isEmpty());
	}

	@Test
	public void testGetSize() {
		playlist.addSong(song1);
		playlist.addSong(song2);
		assertEquals(2, playlist.getSize());
	}

	@Test
	public void testGetCurrentSong() {
		playlist.addSong(song1);
		playlist.addSong(song2);
		Song current = playlist.getCurrentSong();
		assertEquals(song1, current);
	}

	@Test
	public void testNextSong() {
		playlist.addSong(song1);
		playlist.addSong(song2);
		playlist.nextSong();
		assertEquals(song2, playlist.nextSong());
	}

	@Test
	public void testPreviousSong() {
		playlist.addSong(song1);
		playlist.addSong(song2);
		playlist.getCurrentSong();
		playlist.nextSong();
		assertEquals(song1, playlist.previousSong());
	}

	@Test
	public void testRemoveSong() {
		playlist.addSong(song1);
		playlist.addSong(song2);
		assertTrue(playlist.removeSong(song1));
		assertEquals(1, playlist.getSize());
	}

	@Test
	public void testGetSongs() {
		playlist.addSong(song1);
		playlist.addSong(song2);
		GenericLinkedList<Song> songs = playlist.getSongs();
		assertEquals(2, songs.size());
	}
}