import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.ListIterator;

public class GenericLinkedListStudentTest {

	private GenericLinkedList<String> list;

	@Before
	public void setUp() {
		list = new GenericLinkedList<>();
	}

	@Test
	public void testGetFirst() {
		list.addFirst("Apple");
		list.addLast("Banana");
		assertEquals("Apple", list.getFirst());
	}

	@Test
	public void testGetLast() {
		list.addFirst("Apple");
		list.addLast("Banana");
		assertEquals("Banana", list.getLast());
	}

	@Test
	public void testIsEmpty() {
		assertTrue(list.isEmpty());
		list.addLast("Cherry");
		assertFalse(list.isEmpty());
	}

	@Test
	public void testRemoveFirst() {
		list.addLast("Apple");
		list.addLast("Banana");
		list.removeFirst();
		assertEquals("Banana", list.getFirst());
	}

	@Test
	public void testRemoveLast() {
		list.addLast("Apple");
		list.addLast("Banana");
		list.removeLast();
		assertEquals("Apple", list.getLast());
	}

	@Test
	public void testSize() {
		list.addLast("Apple");
		list.addLast("Banana");
		list.addLast("Cherry");
		assertEquals(3, list.size());
	}

	@Test
	public void testRemoveElement() {
		list.addLast("Apple");
		list.addLast("Banana");
		list.remove("Banana");
		assertFalse(list.contains("Banana"));
	}

	@Test
	public void testRemoveIndex() {
		list.addLast("Apple");
		list.addLast("Banana");
		list.addLast("Cherry");
		assertEquals("Banana", list.remove(1));
		assertFalse(list.contains("Banana"));
	}

	@Test
	public void testIteratorPrevious() {
		list.addLast("Apple");
		list.addLast("Banana");
		list.addLast("Apple");
		list.addLast("Banana");
		list.addLast("Apple");
		list.addLast("Banana");

		ListIterator<String> it = list.iterator();
		it.next();
		it.next();
		it.next();
		it.next();
		it.next();
		it.next();

		assertEquals("Apple", it.previous());
	}

	@Test
	public void testToArray() {
		list.addLast("Apple");
		list.addLast("Banana");

		Object[] arr = list.toArray();

		assertEquals("Apple", arr[0]);
		assertEquals("Banana", arr[1]);
	}
}