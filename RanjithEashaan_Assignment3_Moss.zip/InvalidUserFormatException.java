
public class InvalidUserFormatException extends Exception {
	public InvalidUserFormatException(String message) {
		super(message);
	}
	public InvalidUserFormatException() {
		super("Invalid User Format");
	}
}
