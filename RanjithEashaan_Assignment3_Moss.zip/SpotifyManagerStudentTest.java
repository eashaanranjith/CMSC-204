import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.io.*;

public class SpotifyManagerStudentTest {

    private SpotifyManager manager;
    private File tempFile;
    private String testData;

    @Before
    public void setUp() throws IOException {

        manager = new SpotifyManager();

        testData =
                "# USER\n" +
                "username: bob\n" +
                "password: 111\n" +
                "playlist: Grunge\n" +
                "song: Tonight, Tonight - The Smashing Pumpkins\n" +
                "song: Drain You - Nirvana\n" +
                "# USER\n" +
                "username: sara\n" +
                "password: 222\n" +
                "playlist: Pop\n" +
                "song: WildFlower - Billie Eilish\n";

        tempFile = File.createTempFile("student_test_users", ".txt");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            writer.write(testData.replace("\n", System.lineSeparator()));
        }
    }

    @Test
    public void testLoadUsersFromFile() throws Exception {

        manager.loadUsersFromFile(tempFile.getAbsolutePath());

        GenericLinkedList<User> users = manager.getUsers();

        assertEquals(2, users.size());
        assertEquals("bob", users.get(0).getUsername());
        assertEquals("sara", users.get(1).getUsername());
    }

    @Test
    public void testFindUserSuccess() throws Exception {

        manager.loadUsersFromFile(tempFile.getAbsolutePath());

        User user = manager.findUser("bob", "111");

        assertNotNull(user);
        assertEquals("bob", user.getUsername());
        assertEquals("111", user.getPassword());
    }

    @Test
    public void testPlaylistsLoaded() throws Exception {

        manager.loadUsersFromFile(tempFile.getAbsolutePath());

        User user = manager.findUser("bob", "111");

        assertEquals(1, user.getPlaylistCount());
        assertEquals("Grunge", user.getPlaylists().get(0).getName());
    }

    @Test
    public void testSongsLoaded() throws Exception {

        manager.loadUsersFromFile(tempFile.getAbsolutePath());

        User user = manager.findUser("bob", "111");
        Playlist playlist = user.getPlaylists().get(0);

        assertEquals(2, playlist.getSize());
        assertEquals("Tonight, Tonight", playlist.getSongs().get(0).getTitle());
    }
}