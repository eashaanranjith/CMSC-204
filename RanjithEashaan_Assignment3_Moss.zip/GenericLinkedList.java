import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * A generic double linked list implementation that stores elements of type T.
 * The list supports insertion, removal, traversal, and conversion to an array.
 * 
 * @param <T> the type of elements stored in the list
 */
public class GenericLinkedList<T> implements Iterable<T> {
	private Node firstNode;
	private Node lastNode;
	private int currentSize = 0;

	/**
	 * Inserts a new element at the beginning of the list.
	 *
	 * @param value the value to add to the front of the list
	 */
	public void addFirst(T value) {
		if (isEmpty()) {
			firstNode = new Node(value);
			lastNode = firstNode;
		} else {
			Node newNode = new Node(value);
			newNode.nextNode = firstNode;
			firstNode.prevNode = newNode;
			firstNode = newNode;
		}
		currentSize++;

	}

	/**
	 * Appends a new element to the end of the list.
	 *
	 * @param value the value to add to the end of the list
	 */
	public void addLast(T value) {
		if (isEmpty()) {
			firstNode = new Node(value);
			lastNode = firstNode;
		} else {
			Node newNode = new Node(value);
			newNode.prevNode = lastNode;
			lastNode.nextNode = newNode;
			lastNode = newNode;
		}
		currentSize++;
	}

	/**
	 * Removes all elements from the list.
	 */
	public void clear() {
		while (!isEmpty()) {
			removeFirst();
			currentSize--;
		}
	}

	/**
	 * Checks whether the list contains the specified element.
	 *
	 * @param element the element to search for
	 * @return true if the element is found, false otherwise
	 */
	public Boolean contains(T element) {
		ListIterator<T> genIter = this.iterator();
		while (genIter.hasNext()) {
			if (genIter.next() == element) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Retrieves the element at the specified index.
	 *
	 * @param index the index of the element
	 * @return the element at the given index
	 * @throws IndexOutOfBoundsException if the index is invalid
	 */
	public T get(int index) {
		ListIterator<T> genIter = this.iterator();
		for (int i = 0; i < index; i++) {
			if (!genIter.hasNext()) {
				throw new IndexOutOfBoundsException();
			}
			genIter.next();
		}
		return genIter.next();
	}

	/**
	 * Returns the first element in the list.
	 *
	 * @return the first element
	 */
	public T getFirst() {
		return firstNode.value;
	}

	/**
	 * Returns the last element in the list.
	 *
	 * @return the last element
	 */
	public T getLast() {
		return lastNode.value;
	}

	/**
	 * Determines whether the list is empty.
	 *
	 * @return true if the list contains no elements, false otherwise
	 */
	public boolean isEmpty() {
		if (currentSize <= 0) {
			return true;
		}
		return false;
	}

	/**
	 * Returns a ListIterator for traversing the list.
	 *
	 * @return a ListIterator for this list
	 */
	public ListIterator<T> iterator() {
		return new GenericIterator();
	}

	/**
	 * Removes the element at the specified index.
	 *
	 * @param index the index of the element to remove
	 * @return the removed element
	 * @throws IndexOutOfBoundsException if the index is invalid
	 */
	public T remove(int index) {
		ListIterator<T> genIter = this.iterator();
		T search = null;
		for (int i = 0; i < index; i++) {
			if (!genIter.hasNext()) {
				throw new IndexOutOfBoundsException();
			}
			search = genIter.next();
		}
		search = genIter.next();
		genIter.previous();
		genIter.remove();
		return search;
	}

	/**
	 * Removes the first occurrence of the specified element.
	 *
	 * @param element the element to remove
	 * @return true if the element was removed, false otherwise
	 */
	public boolean remove(T element) {
		ListIterator<T> genIter = this.iterator();
		while (genIter.hasNext()) {
			if (genIter.next() == element) {
				genIter.previous();
				genIter.remove();
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes and returns the first element in the list.
	 *
	 * @return the removed element
	 * @throws NoSuchElementException if the list is empty
	 */
	public T removeFirst() {
		if(isEmpty()) {
			throw new NoSuchElementException();
		}
		Node delete = firstNode;
		T value = firstNode.value;
		firstNode = firstNode.nextNode;
		if (firstNode != null) {
			firstNode.prevNode = null;
		}
		delete = null;
		currentSize--;
		return value;
	}

	/**
	 * Removes and returns the last element in the list.
	 *
	 * @return the removed element
	 * @throws NoSuchElementException if the list is empty
	 */
	public T removeLast() {
		if(isEmpty()) {
			throw new NoSuchElementException();
		}
		Node delete = lastNode;
		T value = lastNode.value;
		lastNode = lastNode.prevNode;
		lastNode.nextNode = null;
		delete = null;
		currentSize--;
		return value;
	}

	/**
	 * Returns the number of elements in the list.
	 *
	 * @return the size of the list
	 */
	public int size() {
		return currentSize;
	}

	/**
	 * Converts the list to an array.
	 *
	 * @return an array containing all elements in the list
	 */
	public Object[] toArray() {
		Object[] returnCopy = new Object[currentSize];
		ListIterator<T> genIter = this.iterator();
		int i = 0;
		while (genIter.hasNext()) {
			returnCopy[i] = genIter.next();
			i++;
		}
		return returnCopy;
	}

	/**
	 * Constructs a node with the specified value.
	 *
	 * @param value the value stored in the node
	 */
	public class Node {
		private T value;
		private Node nextNode;
		private Node prevNode;

		public Node(T value) {
			this.value = value;
		}
	}

	/**
	 * An iterator implementation for the GenericLinkedList that allows
	 * bidirectional traversal of the list.
	 */
	public class GenericIterator implements ListIterator<T> {
		private Node current = firstNode;
		private boolean didCall;
		private int index = 0;

		/**
		 * Checks if there is another element after the current position.
		 *
		 * @return true if another element exists
		 */
		@Override
		public boolean hasNext() {
			if (index < currentSize) {
				return true;
			}
			return false;
		}

		/**
		 * Returns the next element in the list.
		 *
		 * @return the next element
		 */
		@Override
		public T next() {
			T value;
			if (hasNext()) {
				value = current.value;
				current = current.nextNode;
				didCall = true;
				index++;
			} else {
				value = null;
			}
			return value;
		}

		/**
		 * Checks if there is a previous element before the current position.
		 *
		 * @return true if a previous element exists
		 */
		@Override
		public boolean hasPrevious() {
			if (index > 0) {
				return true;
			}
			return false;
		}

		/**
		 * Returns the previous element in the list.
		 *
		 * @return the previous element
		 */
		@Override
		public T previous() {
			T value;
			if (hasPrevious()) {
				if (current == null) {
					current = lastNode.prevNode;
				} else {
					current = current.prevNode;
				}
				value = current.value;
				index--;
				didCall = true;
				return value;
			} else {
				value = null;
			}
			return value;
		}

		@Override
		public int nextIndex() {
			throw new UnsupportedOperationException();
		}

		@Override
		public int previousIndex() {
			throw new UnsupportedOperationException();
		}

		/**
		 * Removes the last element returned by next() or previous().
		 *
		 * @throws IllegalStateException if neither next nor previous was called
		 */
		@Override
		public void remove() {
			if (!didCall) {
				throw new IllegalStateException("next or previous has not been called");
			}
			Node delete = current;
			Node prevNode;
			Node nextNode;
			if (current != null) {

				if (current.prevNode != null) {
					prevNode = current.prevNode;
				} else {
					prevNode = current;
				}
				if (current.nextNode != null) {
					nextNode = current.nextNode;
				} else {
					nextNode = current;
				}
				prevNode.nextNode = nextNode;
				nextNode.prevNode = prevNode;
				current = prevNode;
				delete = null;
				currentSize--;
				didCall = false;
			}

		}

		@Override
		public void set(Object e) {
			throw new UnsupportedOperationException();

		}

		@Override
		public void add(Object e) {
			throw new UnsupportedOperationException();
		}
	}
}
