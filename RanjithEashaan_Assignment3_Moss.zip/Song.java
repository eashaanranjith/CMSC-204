/**
 * Represents a song with a title and an artist.
 */
public class Song {
	private String title;
	private String artist;

	/**
	 * Constructs a Song with a title and artist.
	 * 
	 * @param title  the title of the song
	 * @param artist the artist who performs the song
	 */
	public Song(String title, String artist) {
		this.title = title;
		this.artist = artist;
	}

	/**
	 * Constructs a Song with only a title. The artist is set to null.
	 * 
	 * @param title the title of the song
	 */
	public Song(String title) {
		this.title = title;
		this.artist = null;
	}

	/**
	 * Sets the title of the song.
	 * 
	 * @param title the new title for the song
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Sets the artist of the song.
	 * 
	 * @param artist the new artist for the song
	 */
	public void setArtist(String artist) {
		this.artist = artist;
	}

	/**
	 * Returns the title of the song.
	 * 
	 * @return the song title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Returns the artist of the song.
	 * 
	 * @return the song artist
	 */
	public String getArtist() {
		return artist;
	}

	/**
	 * Returns a string representation of the song in the format: "title by artist".
	 * 
	 * @return formatted song information
	 */
	@Override
	public String toString() {
		return title + " by " + artist;
	}
}
