import java.io.*;
import java.util.ListIterator;
import java.util.Scanner;

/**
 * Manages users and their playlists for the Spotify application.
 * Handles loading user data from a file and authenticating users.
 */
public class SpotifyManager {
	private GenericLinkedList<User> userList = new GenericLinkedList<>();

	/**
	 * Loads users, playlists, and songs from a formatted file.
	 *
	 * @param filename the file containing user data
	 * @throws IOException if the file cannot be read
	 * @throws InvalidUserFormatException if the file format is invalid
	 */
	public void loadUsersFromFile(String filename) throws IOException, InvalidUserFormatException {
		Scanner sc = new Scanner(new File(filename));

		User currentUser = null;
		Playlist currentPlaylist = null;
		String username = null;
		String password = null;
		String playListName;
		String songInfo;
		String inputLine;
		while (sc.hasNextLine()) {

			inputLine = sc.nextLine();
			if (inputLine.substring(0,6).equals("# USER")) {
				if (currentUser != null) {
					userList.addLast(currentUser);
				}
				currentUser = null;
				currentPlaylist = null;
				username = null;
				password = null;
				playListName = null;
				songInfo = null;

			} else if (inputLine.substring(0,9).equals("username:")) {
				username = inputLine.substring(10);
				continue;
			} else if (inputLine.substring(0,9).equals("password:")) {
				password = inputLine.substring(10);
				currentUser = new User(username, password);
				continue;
			} else if (inputLine.substring(0,9).equals("playlist:")) {
				playListName = inputLine.substring(10);
				currentPlaylist = new Playlist(playListName);
				currentUser.addPlaylist(currentPlaylist);
				continue;
			} else if (inputLine.substring(0,5).equals("song:")) {
				songInfo = inputLine.substring(6);
				currentPlaylist.addSong(new Song(songInfo.substring(0, songInfo.indexOf("-") - 1),
						songInfo.substring(songInfo.indexOf("-") + 2, songInfo.length())));
				continue;
			}
		}
		sc.close();
		if (currentUser != null) {
		    userList.addLast(currentUser);
		} else {
			throw new InvalidUserFormatException();
		}
	}

	/**
	 * Finds a user with the given username and password.
	 *
	 * @param username the username to search for
	 * @param password the password for authentication
	 * @return the matching User
	 * @throws UserNotFoundException if the user does not exist
	 * @throws InvalidPasswordException if the password is incorrect
	 */
	public User findUser(String username, String password) throws UserNotFoundException, InvalidPasswordException {
		ListIterator<User> userIter = userList.iterator();
		User currentCheck;
		while (userIter.hasNext()) {
			currentCheck = userIter.next();
			if (currentCheck.getUsername().equals(username)) {
				if (currentCheck.getPassword().equals(password)) {
					return currentCheck;
				}
				throw new InvalidPasswordException();
			}
		}
		throw new UserNotFoundException();
	}

	/**
	 * Returns a shallow copy of the users in the user list.
	 * 
	 * @return a GenericLinkedList containing the users
	 */
	public GenericLinkedList<User> getUsers() {
		GenericLinkedList<User> copy = new GenericLinkedList<>();
		copy = userList;
		return copy;
	}
}
