import java.util.ListIterator;

/**
 * Represents a playlist that contains a name and a list of songs. The playlist
 * allows navigation through songs using a ListIterator to move forward and
 * backward through the playlist.
 */
public class Playlist {
	private String name;
	private GenericLinkedList<Song> playlist = new GenericLinkedList<>();
	private ListIterator<Song> listIter = playlist.iterator();

	/**
	 * Constructs a Playlist with the given name.
	 * 
	 * @param name the name of the playlist
	 */
	public Playlist(String name) {
		this.name = name;
	}

	/**
	 * Returns the name of the playlist.
	 * 
	 * @return the playlist name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Adds a song to the playlist. The iterator is reset after a song is added.
	 * 
	 * @param song the song to add
	 * @return true if the song was successfully added, false if the song is null
	 */
	public Boolean addSong(Song song) {
		if (song != null) {
			playlist.addLast(song);
			listIter = playlist.iterator();
			return true;
		}
		return false;
	}

	/**
	 * Returns the current song in the playlist.
	 * 
	 * @return the current song
	 */
	public Song getCurrentSong() {
		Song current = listIter.next();
		listIter.previous();
		return current;
	}

	/**
	 * Returns the number of songs in the playlist.
	 * 
	 * @return the size of the playlist
	 */
	public int getSize() {
		return playlist.size();
	}

	/**
	 * Returns a shallow copy of the songs in the playlist.
	 * 
	 * @return a GenericLinkedList containing the songs
	 */
	public GenericLinkedList<Song> getSongs() {
		GenericLinkedList<Song> copy = new GenericLinkedList<>();
		copy = playlist;
		return copy;
	}

	/**
	 * Checks whether the playlist is empty.
	 * 
	 * @return true if the playlist contains no songs, false otherwise
	 */
	public Boolean isEmpty() {
		return playlist.isEmpty();
	}

	/**
	 * Moves the iterator to the next song in the playlist.
	 * 
	 * @return the next song
	 */
	public Song nextSong() {
		return listIter.next();
	}

	/**
	 * Moves the iterator to the previous song in the playlist.
	 * 
	 * @return the previous song
	 */
	public Song previousSong() {
		return listIter.previous();
	}

	/**
	 * Removes a song from the playlist.
	 * 
	 * @param song the song to remove
	 * @return true if a song was removed, false if the playlist is empty
	 */
	public Boolean removeSong(Song song) {
		if (!isEmpty()) {
			playlist.remove(song);
			return true;
		}
		return false;
	}
}
