/**
 * Represents a user with a username, password, and a list of playlists.
 */
public class User {
	private String username;
	private String password;
	private int playlistCount = 0;
	GenericLinkedList<Playlist> userList = new GenericLinkedList<>();

	/**
     * Constructs a new User with the given username and password.
     * 
     * @param username the username of the user
     * @param password the password of the user
     */
	public User(String username, String password) {
		this.username = username;
		this.password = password;
	}

	/**
    * Returns the username of this user.
    * 
    * @return the username
    */
	public String getUsername() {
		return username;
	}

	 /**
     * Returns the password of this user.
     * 
     * @return the password
     */
	public String getPassword() {
		return password;
	}

	/**
     * Adds a playlist to this user's playlist list and increments the playlist count.
     * 
     * @param playlist the playlist to add
     */
	public void addPlaylist(Playlist playlist) {
		userList.addLast(playlist);
		playlistCount++;

	}

	/**
     * Returns the number of playlists this user has.
     * 
     * @return the playlist count
     */
	public int getPlaylistCount() {
		return playlistCount;
	}

	/**
     * Returns a copy of this user's playlists.
     * 
     * @return a GenericLinkedList containing the user's playlists
     */
	public GenericLinkedList<Playlist> getPlaylists() {
		GenericLinkedList<Playlist> copy = new GenericLinkedList<>();
		copy = userList;
		return copy;
	}
}
