import java.util.LinkedList;
import java.util.Queue;
public class CarQueue {
	private Queue<Integer> carQueue;
	
	public CarQueue() {
		carQueue = new LinkedList<Integer>();;
		for(int i = 0; i < 6; i ++) {
			addToQueue();
		}
	}
	
	public void addToQueue() {
		class runQueue implements Runnable{

			@Override
			public void run() {
				int i = (int) (Math.random() % 4);
				carQueue.add(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
		Thread t = new Thread(new runQueue());
		t.start();
	}
	public int deleteQueue(){
		if(carQueue.isEmpty()) {
			return -1;
		}else{
			return carQueue.remove();
		}
	}
	
	
}
