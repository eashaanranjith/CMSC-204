import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

import org.junit.jupiter.api.Test;

class MyPriorityQueueStudentTest {
	// I took the class from the other test file to check stuff
	// --- A very simple class used only in this test file ---
	private static class Task {
		private final String name;
		private final int priority; // smaller number = higher priority

		Task(String name, int priority) {
			this.name = name;
			this.priority = priority;
		}

		String getName() {
			return name;
		}

		int getPriority() {
			return priority;
		}

		@Override
		public String toString() {
			return name + "(p=" + priority + ")";
		}
	}

	// Orders by priority ascending; if tie, by name alphabetically
	private static final Comparator<Task> TASK_COMPARATOR = new Comparator<Task>() {
		@Override
		public int compare(Task t1, Task t2) {
			int c = Integer.compare(t1.getPriority(), t2.getPriority());
			if (c != 0)
				return c;
			return t1.getName().compareTo(t2.getName());
		}
	};

	// Simple comparator for integers (ascending)
	private static final Comparator<Integer> INT_ASC = new Comparator<Integer>() {
		@Override
		public int compare(Integer a, Integer b) {
			return a.compareTo(b);
		}
	};

	@Test
	public void testEnqueueAndSize() {
		MyPriorityQueue<Task> pq = new MyPriorityQueue<>(TASK_COMPARATOR);

		pq.enqueue(new Task("A", 3));

		assertEquals(1, pq.size());
	}

	@Test
	public void testDequeue() {
		MyPriorityQueue<Task> pq = new MyPriorityQueue<>(TASK_COMPARATOR);

		pq.enqueue(new Task("lower", 5));
		pq.enqueue(new Task("higher", 1));

		Task t = pq.dequeue();

		assertEquals("higher", t.getName());
	}

	@Test
	public void testPeek() {
		MyPriorityQueue<Task> pq = new MyPriorityQueue<>(TASK_COMPARATOR);

		pq.enqueue(new Task("t1", 4));
		pq.enqueue(new Task("t2", 2));

		Task t = pq.peek();

		assertEquals("t2", t.getName());
	}

	@Test
	public void testIsEmpty() {
		MyPriorityQueue<Integer> pq = new MyPriorityQueue<>(INT_ASC);

		assertTrue(pq.isEmpty());

		pq.enqueue(10);

		assertFalse(pq.isEmpty());
	}

	@Test
	public void testSize() {
		MyPriorityQueue<Integer> pq = new MyPriorityQueue<>(INT_ASC);

		pq.enqueue(1);
		pq.enqueue(2);

		assertEquals(2, pq.size());
	}

	@Test
	public void testToArray() {
		MyPriorityQueue<Task> pq = new MyPriorityQueue<>(TASK_COMPARATOR);

		pq.enqueue(new Task("A", 3));
		pq.enqueue(new Task("B", 1));

		Object[] array = pq.toArray();

		assertEquals(2, array.length);

		Task check = (Task) array[0];
		assertEquals("B", check.getName());
	}

}
