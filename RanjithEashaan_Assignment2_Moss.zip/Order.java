/**
 * Represents a single order in the warehouse simulation. Each order has an ID,
 * an arrival time, and a shipping deadline.
 */
public class Order {
	private String orderID;
	private int arrivalMinute;
	private int deadlineMinute;

	/**
	 * Constructs an Order with the given ID and deadline.
	 *
	 * @param orderID  the unique identifier for the order
	 * @param deadline the deadline minute by which the order should be shipped
	 */
	public Order(String orderID, int deadline) {
		this.orderID = orderID;
		this.deadlineMinute = deadline;
	}

	/**
	 * Returns the order's ID.
	 *
	 * @return the order ID
	 */
	public String getId() {
		return orderID;
	}

	/**
	 * Returns the minute the order arrived.
	 *
	 * @return arrival minute
	 */
	public int getArrivalMinute() {
		return arrivalMinute;
	}

	/**
	 * Returns the deadline minute for shipping the order.
	 *
	 * @return deadline minute
	 */
	public int getDeadlineMinute() {
		return deadlineMinute;
	}

	/**
	 * Sets the order's ID.
	 *
	 * @param orderID the new order ID
	 */
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	/**
	 * Sets the arrival minute of the order.
	 *
	 * @param arrivalMinute the minute the order arrived
	 */
	public void setArrivalMinute(int arrivalMinute) {
		this.arrivalMinute = arrivalMinute;
	}

	/**
	 * Sets the deadline minute for the order.
	 *
	 * @param deadlineMinute the new deadline minute
	 */
	public void setDeadlineMinute(int deadlineMinute) {
		this.deadlineMinute = deadlineMinute;
	}
}
