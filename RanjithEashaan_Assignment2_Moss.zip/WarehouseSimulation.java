/**
 * Represents a simple time-driven simulation.
 */
public class WarehouseSimulation implements SimulationInterface {
	private final int DEFAULT_SIZE = 4;
	private Order[] orders;
	private int currentMinute = 0;
	private int totalArrived = 0;
	private int totalShipped = 0;
	private int totalLate = 0;


    /**
     * Constructs a simulation using the provided array of orders.
     *
     * @param orders the orders to be processed during the simulation
     */
	public WarehouseSimulation(Order[] orders) {
		this.orders = orders;
	}

	/**
    * Constructs a simulation with a default-sized empty order array.
    * No actual orders are present until they are added manually.
    */
	public WarehouseSimulation() {
		this.orders = new Order[DEFAULT_SIZE];
	}

	/**
	 * Advance the simulation by exactly one minute. This may involve: - Adding new
	 * orders to the queue - Shipping one order - Moving late orders to the returns
	 * stack
	 */
	@Override
	public void tick() {
		totalArrived++;
		if (orders[totalShipped].getDeadlineMinute() < currentMinute) {
			totalLate++;
		}
		totalShipped++;
		currentMinute++;
	}

	/**
	 * Returns true if: - All orders have been released into the queue, AND - The
	 * queue is empty (all orders shipped).
	 */
	@Override
	public boolean isFinished() {
		if (totalShipped >= orders.length) {
			return true;
		}
		return false;
	}

	/** Returns the current simulation time in minutes. */
	@Override
	public int getCurrentMinute() {
		return currentMinute;
	}

	/** Returns the total number of orders that have arrived. */
	@Override
	public int getTotalArrived() {
		return totalArrived;
	}

	/** Returns the total number of orders that have been shipped. */
	@Override
	public int getTotalShipped() {
		return totalShipped;
	}

	/** Returns the total number of orders that shipped late. */
	@Override
	public int getTotalLate() {
		return totalLate;
	}

}
