import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyStackStudentTest {

	@Test
	public void testPush() {
		MyStack<Integer> stack = new MyStack<>();

		stack.push(10);

		assertEquals(1, stack.size());
	}

	@Test
	public void testPop() {
		MyStack<String> stack = new MyStack<>();

		stack.push("A");
		stack.push("B");

		String value = stack.pop();

		assertEquals("B", value);
	}

	@Test
	public void testPeek() {
		MyStack<Integer> stack = new MyStack<>();

		stack.push(5);
		stack.push(9);

		int value = stack.peek();

		assertEquals(9, value);
	}

	@Test
	public void testIsEmpty() {
		MyStack<Integer> stack = new MyStack<>();

		assertTrue(stack.isEmpty());

		stack.push(1);

		assertFalse(stack.isEmpty());
	}

	@Test
	public void testSize() {
		MyStack<Integer> stack = new MyStack<>();

		stack.push(1);
		stack.push(2);

		assertEquals(2, stack.size());
	}

	@Test
	public void testToArray() {
		MyStack<String> stack = new MyStack<>();

		stack.push("X");
		stack.push("Y");

		Object[] array = stack.toArray();

		assertEquals(2, array.length);
		assertEquals("X", array[0]);
		assertEquals("Y", array[1]);
	}

}
