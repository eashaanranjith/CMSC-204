import java.util.NoSuchElementException;

/**
 * Generic LIFO (last-in-first-out) stack Default size of 10 if the size is not
 * declared.
 * 
 * @param <T> the type of elements stored in the stack
 */
public class MyStack<T> implements StackADT<T> {
	private T[] array;
	private final int DEFAULT_CAPACITY = 10;
	int top;

	/**
	 * No-argument constructor. Creates an empty stack with the default capacity.
	 * Initializes the internal array and sets top to -1.
	 */
	@SuppressWarnings("unchecked")
	public MyStack() {
		this.array = (T[]) new Object[DEFAULT_CAPACITY];
		top = -1;
	}

	/**
	 * Pushes an item onto the top of the stack.
	 * 
	 * @param item the element to push
	 * @throws IllegalArgumentException if item is null
	 * @throws IllegalStateException    if stack has reached max capacity
	 */
	@Override
	public void push(T item) {
		if (top >= DEFAULT_CAPACITY) {
			throw new IllegalStateException("MyStack is full");
		}
		if (item == null) {
			throw new IllegalArgumentException("Cant push null");
		}
		array[top + 1] = item;
		top++;

	}

	/**
	 * Removes and returns the top item from the stack.
	 * 
	 * @return the popped element
	 * @throws NoSuchElementException if the stack is empty
	 */
	@Override
	public T pop() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		T temp = array[top];
		array[top] = null;
		top--;
		return temp;
	}

	/**
	 * Returns the top item of the stack without removing.
	 * 
	 * @return the top element
	 * @throws NoSuchElementException if the stack is empty
	 */
	@Override
	public T peek() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		return array[top];
	}

	/**
	 * Checks whether the stack is empty.
	 * 
	 * @return true if the stack has no elements, false otherwise
	 */
	@Override
	public boolean isEmpty() {
		if (top < 0) {
			return true;
		}
		return false;
	}

	/**
	 * Returns the current number of elements in the stack.
	 * 
	 * @return number of elements
	 */
	@Override
	public int size() {
		return top + 1;
	}

	/**
	 * Returns an array containing all elements in this stack. The element at index
	 * 0 is the bottom of the stack, and the element at index size()-1 is the top.
	 */
	@Override
	public Object[] toArray() {
		Object[] returnCopy = new Object[top + 1];
		for (int i = 0; i <= top; i++) {
			returnCopy[i] = array[i];
		}
		return returnCopy;
	}

}
