import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WarehouseSimulationStudentTest {
	@Test
	public void testTickUpdatesCounts() {
		Order[] orders = { new Order("A", 5), new Order("B", 5) };

		WarehouseSimulation sim = new WarehouseSimulation(orders);

		while (!sim.isFinished()) {
			sim.tick();
		}

		assertEquals(2, sim.getTotalArrived());
		assertEquals(2, sim.getTotalShipped());
		assertEquals(2, sim.getCurrentMinute());
	}

	@Test
	public void testIsFinished() {
		Order[] orders = { new Order("A", 5) };

		WarehouseSimulation sim = new WarehouseSimulation(orders);

		assertFalse(sim.isFinished());

		while (!sim.isFinished()) {
			sim.tick();
		}

		assertTrue(sim.isFinished());
	}

	@Test
	public void testGetCurrentMinute() {
		Order[] orders = { new Order("A", 5) };

		WarehouseSimulation sim = new WarehouseSimulation(orders);

		while (!sim.isFinished()) {
			sim.tick();
		}

		assertEquals(1, sim.getCurrentMinute());
	}

	@Test
	public void testGetTotalArrived() {
		Order[] orders = { new Order("A", 5), new Order("B", 5) };

		WarehouseSimulation sim = new WarehouseSimulation(orders);

		while (!sim.isFinished()) {
			sim.tick();
		}

		assertEquals(2, sim.getTotalArrived());
	}

	@Test
	public void testGetTotalShipped() {
		Order[] orders = { new Order("A", 5), new Order("B", 5) };

		WarehouseSimulation sim = new WarehouseSimulation(orders);

		while (!sim.isFinished()) {
			sim.tick();
		}

		assertEquals(2, sim.getTotalShipped());
	}

	@Test
	public void testGetTotalLate() {
		Order[] orders = { new Order("not late", 0), new Order("late", 0) };

		WarehouseSimulation sim = new WarehouseSimulation(orders);

		while (!sim.isFinished()) {
			sim.tick();
		}

		assertEquals(1, sim.getTotalLate());
	}
}
