import java.util.Comparator;
import java.util.NoSuchElementException;

/**
 * An array-based implementation of a priority queue. This implementation uses a
 * fixed-capacity array and shifts elements during insertion and removal to
 * maintain order.
 *
 * @param <T> the type of elements stored in the queue
 */
public class MyPriorityQueue<T> implements PriorityQueueADT<T> {
	private T[] array;
	private final int DEFAULT_CAPACITY = 10;
	private Comparator<T> compare;
	private int currentSize;

	/**
	 * Constructs an empty priority queue using the specified comparator to
	 * determine element priority.
	 *
	 * @param compare the comparator used to order elements by priority
	 */
	@SuppressWarnings("unchecked")
	public MyPriorityQueue(Comparator<T> compare) {
		this.compare = compare;
		this.array = (T[]) new Object[DEFAULT_CAPACITY];
		currentSize = 0;
	}

	/**
	 * Inserts an item into the queue according to the priority order.
	 * 
	 * @param item the element to insert (cannot be null)
	 * @throws IllegalArgumentException if item is null
	 */
	@Override
	public void enqueue(T item) {
		if (currentSize >= DEFAULT_CAPACITY) {
			throw new IllegalStateException("PriorityQueue is full");
		}
		int i = currentSize - 1;
		while (i >= 0 && compare.compare(item, array[i]) < 0) {
			array[i + 1] = array[i];
			i--;
		}
		array[i + 1] = item;
		currentSize++;

	}

	/**
	 * Removes and returns the highest-priority item.
	 * 
	 * @return the dequeued element
	 * @throws NoSuchElementException if the queue is empty
	 */
	@Override
	public T dequeue() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		T temp = array[0];
		for (int i = 0; i < currentSize; i++) {
			array[i] = array[i + 1];
		}
		array[currentSize] = null;
		currentSize--;
		return temp;
	}

	/**
	 * Returns (without removing) the highest-priority item.
	 * 
	 * @return the front element
	 * @throws NoSuchElementException if the queue is empty
	 */
	@Override
	public T peek() {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		return array[0];
	}

	/**
	 * Checks whether the queue has no elements.
	 * 
	 * @return true if empty, false otherwise
	 */
	@Override
	public boolean isEmpty() {
		if (currentSize == 0) {
			return true;
		}
		return false;
	}

	/**
	 * Returns the current number of elements in the queue.
	 * 
	 * @return number of elements
	 */
	@Override
	public int size() {
		return currentSize;
	}

	/**
	 * Returns an array containing all elements in this priority queue, in the
	 * current internal order (not necessarily sorted by priority).
	 */
	@Override
	public Object[] toArray() {
		Object[] returnCopy = new Object[currentSize];
		for (int i = 0; i < currentSize; i++) {
			returnCopy[i] = array[i];
		}
		return returnCopy;
	}
}
