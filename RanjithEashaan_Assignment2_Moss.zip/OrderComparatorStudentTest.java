import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OrderComparatorStudentTest {

	@Test
	public void testCompareDeadline() {
		Order o1 = new Order("A", 5);
		Order o2 = new Order("B", 2);
		OrderComparator cmp = new OrderComparator();

		assertEquals(cmp.compare(o1, o2), 1);
	}

	@Test
	public void testCompareArrival() {
		Order o1 = new Order("A", 3);
		o1.setArrivalMinute(1);
		Order o2 = new Order("B", 3);
		o2.setArrivalMinute(2);
		OrderComparator cmp = new OrderComparator();

		assertEquals(cmp.compare(o1, o2), -1);
	}

	@Test
	public void testCompareEqual() {
		Order o1 = new Order("A", 4);
		o1.setArrivalMinute(2);
		Order o2 = new Order("B", 4);
		o2.setArrivalMinute(2);

		OrderComparator cmp = new OrderComparator();

		assertEquals(cmp.compare(o1, o2), 0);
	}

}
