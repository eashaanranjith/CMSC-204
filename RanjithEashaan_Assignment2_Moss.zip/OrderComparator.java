import java.util.Comparator;

/**
 * A Comparator for Order objects. Orders are prioritized by earliest deadline
 * minute first. If deadlines are equal, orders with earlier arrival minute are
 * prioritized.
 */
public class OrderComparator implements Comparator<Order> {

	/**
	 * Compares two Order objects based on deadline minute, then arrival minute.
	 *
	 * @param o1 the first order to compare
	 * @param o2 the second order to compare
	 * @return a negative integer if o1 has higher priority, zero if both orders
	 *         have equal priority, a positive integer if o2 has higher priority
	 */
	@Override
	public int compare(Order o1, Order o2) {
		if (o1.getDeadlineMinute() < o2.getDeadlineMinute()) {
			return -1;
		} else if (o1.getDeadlineMinute() == o2.getDeadlineMinute()) {
			if (o1.getArrivalMinute() < o2.getArrivalMinute()) {
				return -1;
			} else if (o1.getArrivalMinute() == o2.getArrivalMinute()) {
				return 0;
			} else if (o1.getArrivalMinute() > o2.getArrivalMinute()) {
				return 1;
			}
		}
		return 1;
	}

}
