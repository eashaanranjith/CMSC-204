import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class MorseCodeConverter {
	private static MorseCodeTree tree = new MorseCodeTree();

	public static String convertToEnglish(File codeFile) throws FileNotFoundException {
		Scanner sc = new Scanner(codeFile);
		StringBuilder output = new StringBuilder();
		while (sc.hasNextLine()) {
			output.append(convertToEnglish(sc.nextLine()));
		}
		sc.close();
		return output.toString().trim();
	}

	public static String convertToEnglish(String code) {
		StringBuilder output = new StringBuilder();
		int word = 0;
		for (int i = 0; i <= code.length(); i++) {
			if (i == code.length() || code.charAt(i) == '/') {
				int letter = word;
				for (int j = word; j <= i; j++) {
					if (j == i || code.charAt(j) == ' ') {
						if (j > letter) {
							output.append(tree.fetch(code.substring(letter, j)));
						}
						letter = j + 1;
					}
				}
				word = i + 1;
				output.append(" ");
			}
		}
		return output.toString().trim();
	}

	public static String printTree() {
		ArrayList<String> treeList;
		treeList = tree.toArrayList();
		StringBuilder out = new StringBuilder();
		for (String x : treeList) {
			out.append(x + " ");
		}
		return out.toString().trim();
	}
}
