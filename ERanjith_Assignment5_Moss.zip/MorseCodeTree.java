import java.util.ArrayList;

public class MorseCodeTree implements LinkedConverterTreeInterface<String> {
	private TreeNode<String> root;
	
	public MorseCodeTree() {
		buildTree();
	}

	@Override
	public TreeNode<String> getRoot() {
		return root;
	}

	@Override
	public void setRoot(TreeNode<String> newNode) {
		root = new TreeNode<String>(newNode);
	}

	@Override
	public void insert(String code, String result) {
		addNode(root, code, result);
	}

	@Override
	public void addNode(TreeNode<String> root, String code, String letter) {
		if (code.length() == 1) {
			if (code.charAt(0) == '.') {
				root.setLeftChild(new TreeNode<String>(letter));
			}
			if (code.charAt(0) == '-') {
				root.setRightChild(new TreeNode<String>(letter));
			}
		} else {
			if (code.charAt(0) == '.') {
				if (root.getLeftChild() == null) {
					root.setLeftChild(new TreeNode<String>("empty"));
				}
				addNode(root.getLeftChild(), code.substring(1), letter);
			}
			if (code.charAt(0) == '-') {
				if (root.getRightChild() == null) {
					root.setRightChild(new TreeNode<String>("empty"));
				}
				addNode(root.getRightChild(), code.substring(1), letter);
			}
		}
	}

	@Override
	public String fetch(String code) {
		return fetchNode(root, code);
	}

	@Override
	public String fetchNode(TreeNode<String> root, String code) {
		if (code.length() == 1) {
			if (code.charAt(0) == '.') {
				return root.getLeftChild().getData();
			}
			if (code.charAt(0) == '-') {
				return root.getRightChild().getData();
			}
		} else {
			if (code.charAt(0) == '.') {
				if (root.getLeftChild() == null) {
					root.setLeftChild(new TreeNode<String>("empty"));
				}
				return fetchNode(root.getLeftChild(), code.substring(1));
			}
			if (code.charAt(0) == '-') {
				if (root.getRightChild() == null) {
					root.setRightChild(new TreeNode<String>("empty"));
				}
				return fetchNode(root.getRightChild(), code.substring(1));
			}
		}
		return "Something went wrong";
	}

	@Override
	public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void buildTree() {
		root = new TreeNode<String>("");
		insert(".", "e");
	    insert("-", "t");
	    insert("..", "i");
	    insert(".-", "a");
	    insert("-.", "n");
	    insert("--", "m");
	    insert("...", "s");
	    insert("..-", "u");
	    insert(".-.", "r");
	    insert(".--", "w");
	    insert("-..", "d");
	    insert("-.-", "k");
	    insert("--.", "g");
	    insert("---", "o");
	    insert("....", "h");
	    insert("...-", "v");
	    insert("..-.", "f");
	    insert(".-..", "l");
	    insert(".--.", "p");
	    insert(".---", "j");
	    insert("-...", "b");
	    insert("-..-", "x");
	    insert("-.-.", "c");
	    insert("-.--", "y");
	    insert("--..", "z");
	    insert("--.-", "q");
	}

	@Override
	public ArrayList<String> toArrayList() {
		ArrayList<String> output = new ArrayList<>();
		LNRoutputTraversal(root, output);
		return output;
	}

	@Override
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		if(root != null) {
			LNRoutputTraversal(root.getLeftChild(), list);
			list.add(root.getData());
			LNRoutputTraversal(root.getRightChild(), list);
		}

	}

}
