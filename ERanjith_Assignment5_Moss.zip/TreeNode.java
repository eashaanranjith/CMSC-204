
public class TreeNode<T> {
	private T data;
	private TreeNode<T> leftChild;
	private TreeNode<T> rightChild;
	public TreeNode (T dataNode){
		data = dataNode;
		leftChild = null;
		rightChild = null;
	}
	public TreeNode(TreeNode<T> node) {
		data = node.getData();
		leftChild = node.getLeftChild();
		rightChild = node.getRightChild();
		
	}
	public T getData() {
		return data;
	}
	public TreeNode<T> getLeftChild() {
		return leftChild;
	}
	public TreeNode<T> getRightChild() {
		return rightChild;
	}
	public void setLeftChild(TreeNode<T> left) {
		leftChild = left;
	}
	public void setRightChild(TreeNode<T> right) {
		rightChild = right;
	}
}
