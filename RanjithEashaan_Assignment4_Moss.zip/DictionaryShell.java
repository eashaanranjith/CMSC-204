import java.io.*;
import java.util.Scanner;
import java.util.List;

public class DictionaryShell extends Object {
	public static void main(String[] args) {
		DictionaryBuilder dictionary = null;
		if (args.length > 0) {
			try {
				dictionary = new DictionaryBuilder(args[0]);
			} catch (FileNotFoundException e) {
				dictionary = new DictionaryBuilder(13);
			}
		} else {
			dictionary = new DictionaryBuilder(13);
		}
		Scanner sc = new Scanner(System.in);
		while (sc.hasNextLine()) {
			String inputLine = sc.nextLine();
			if (inputLine.substring(0, 3).toLowerCase().equals("add")) {
				dictionary.addWord(inputLine.substring(4));
				System.out.println(inputLine.substring(4) + " added");
				continue;
			}
			if (inputLine.substring(0, 4).toLowerCase().equals("exit")) {
				break;
			}
			if (inputLine.substring(0, 4).toLowerCase().equals("list")) {
				List<String> list = dictionary.getAllWords();
				for (int i = 0; i < list.size(); i++) {
					System.out.println(list.get(i));
				}
				continue;
			}
			if (inputLine.substring(0, 5).toLowerCase().equals("stats")) {
				List<String> words = dictionary.getAllWords();
				int total = 0;
				for (int i = 0; i < words.size(); i++) {
					total += dictionary.getFrequency(words.get(i));
				}
				System.out.println("total words: " + total);
				System.out.println("unique words: " + words.size());
				for (int i = 0; i < words.size(); i++) {
					System.out.println(words.get(i) + ": " + dictionary.getFrequency(words.get(i)));
				}
				System.out.println("load factor = "  + (double)(words.size())/dictionary.getSize());
				continue;
			}
			if (inputLine.substring(0, 6).toLowerCase().equals("search")) {
				if (dictionary.getFrequency(inputLine.substring(7)) > 0) {
					System.out.println(
							inputLine.substring(7) + " exists:  " + dictionary.getFrequency(inputLine.substring(7)));
				}
				continue;
			}
			if (inputLine.substring(0, 6).toLowerCase().equals("delete")) {
				try {
					dictionary.removeWord(inputLine.substring(7));
				} catch (DictionaryEntryNotFoundException e) {
					System.out.println("No Such entry Found");
				}
			}
			continue;
		}
		sc.close();
	}
}
