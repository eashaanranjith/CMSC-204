import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DictionaryBuilderStudentTest {
	@Test
	void testAddWord() {
		DictionaryBuilder dictionary = new DictionaryBuilder(5);
		dictionary.addWord("Test");
		dictionary.addWord("test!!");
		dictionary.addWord("Wrong");
		assertEquals(dictionary.getFrequency("test"), 2);
	}
	@Test
	void testGetAllWords() {
		DictionaryBuilder dictionary = new DictionaryBuilder(5);
		dictionary.addWord("Test");
		dictionary.addWord("test!!");
		dictionary.addWord("Wrong");
		List<String> testList = new ArrayList<>();
		testList.add("test");
		testList.add("wrong");
		assertEquals(testList, dictionary.getAllWords());
	}
	@Test
	void testGetFrequency() {
		DictionaryBuilder dictionary = new DictionaryBuilder(5); // same thing as test addWord because it uses eachother to test eachother
		dictionary.addWord("Test");
		dictionary.addWord("test!!");
		dictionary.addWord("Wrong");
		assertEquals(dictionary.getFrequency("test"), 2);
	}
	@Test
	void testRemoveWord() throws DictionaryEntryNotFoundException {
		DictionaryBuilder dictionary = new DictionaryBuilder(5); 
		dictionary.addWord("Test");
		dictionary.addWord("test!!");
		dictionary.addWord("Wrong");
		dictionary.removeWord("test");
		assertEquals(dictionary.getFrequency("test"), 0);
		assertEquals(dictionary.getFrequency("wrong"), 1);
	}
	@Test
	void testSize() throws DictionaryEntryNotFoundException {
		DictionaryBuilder dictionary = new DictionaryBuilder(5); 
		assertEquals(dictionary.getSize(), 7); // 7 is the next 4k + 3 prime
	}
}
