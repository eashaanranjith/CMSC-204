import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GenericLinkedListStudentTest {

//only changes were adding something that returns the node and a count to the node and making all my == into .equals because thats what they should have been
	@Test
	void testContainsNodeand() {
		GenericLinkedList<String> testList = new GenericLinkedList<>();
		testList.addFirst("test1");
		testList.addFirst("test2");
		testList.addFirst("test3");
		assertEquals(testList.containsNode("test2").count, 1);
	}

}
