
public class DictionaryEntryNotFoundException extends Exception {
	public DictionaryEntryNotFoundException(String message) {
		super(message);
	}
	public DictionaryEntryNotFoundException() {
		super("No entry found");
	}
}
