import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class DictionaryBuilder extends Object {
	private static final double LOAD_FACTOR = 0.6;
	private GenericLinkedList<Object>[] dictionary;
	private int finalSize;

	public DictionaryBuilder(int estimatedEntries) {
		int primeSize = 0;
		boolean isPrime = true;
		for (int i = estimatedEntries; i < 997; i++) { // this checks if its prime and if its a 4k + 3 num but maxes out at the
											// largest 3 digit prime because i dont think it will need to be bigger for
											// this project
			isPrime = true;
			for (int j = 2; j <= Math.sqrt(i); j++) {
				if (i % j == 0) {
					isPrime = false;
				}
			}
			if (isPrime && i % 4 == 3) {
				primeSize = i;
				finalSize = primeSize;
				break;
			}
		}
		dictionary = new GenericLinkedList[primeSize];
		for (int i = 0; i < primeSize; i++) {
			dictionary[i] = new GenericLinkedList<>();
		}
	}

	public DictionaryBuilder(String fileName) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(fileName));
		int unique = 1000 / 100; // the sample file is 1kb and 100 bytes per unique word like in the doc
		int size = (int) (unique / LOAD_FACTOR); // load factor is 0.6 in the javadoc and it says to divide by 0.6 in
													// the instructions so i just assumed
		int primeSize = 0;
		boolean isPrime = true;
		for (int i = size; i < 997; i++) { // this checks if its prime and if its a 4k + 3 num but maxes out at the
											// largest 3 digit prime because i dont think it will need to be bigger for
											// this project
			isPrime = true;
			for (int j = 2; j <= Math.sqrt(i); j++) {
				if (i % j == 0) {
					isPrime = false;
				}
			}
			if (isPrime && i % 4 == 3) {
				primeSize = i;
				finalSize = primeSize;
				break;
			}
		}
		dictionary = new GenericLinkedList[primeSize];
		for (int i = 0; i < primeSize; i++) {
			dictionary[i] = new GenericLinkedList<>();
		}
		while (sc.hasNext()) {
			String word = sc.next().toLowerCase();
			addWord(word);
		}
		sc.close();
	}

	public void addWord(String word) {
		word = word.toLowerCase();
		while (word.length() > 0 && word.charAt(word.length() - 1) < 97) {
			word = word.substring(0, word.length() - 1);
		}
		int position = Math.abs(word.hashCode() % finalSize);
		if (getFrequency(word) < 1) {
			dictionary[position].addLast(word);
		} else {
			dictionary[position].containsNode(word).count += 1;
		}
	}

	public List<String> getAllWords() {
		List<String> sortedWords = new ArrayList<String>();
		for (int i = 0; i < finalSize; i++) {
			for (int j = 0; j < dictionary[i].size(); j++) {
				sortedWords.add((String) dictionary[i].get(j));
			}
		}
		sortedWords.sort(Comparator.naturalOrder());
		return sortedWords;
	}

	public int getFrequency(String word) {
		int count = 0;
		word = word.toLowerCase();
		while (word.length() > 0 && word.charAt(word.length() - 1) < 97) {
			word = word.substring(0, word.length() - 1);
		}
		int position = Math.abs(word.hashCode() % finalSize);
		if (dictionary[position].contains(word)) {
			count = dictionary[position].containsNode(word).count;
		}
		return count;
	}

	public void removeWord(String word) throws DictionaryEntryNotFoundException {
		word = word.toLowerCase();
		while (word.length() > 0 && word.charAt(word.length() - 1) < 97) {
			word = word.substring(0, word.length() - 1);
		}
		int position = Math.abs(word.hashCode() % finalSize);
		if (!dictionary[position].contains(word)) {
			throw new DictionaryEntryNotFoundException();
		} else {
			dictionary[position].remove(word);
		}
	}
	public int getSize() {
		return finalSize;
	}
}
