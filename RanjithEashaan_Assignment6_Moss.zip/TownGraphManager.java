import java.io.File;
import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Set;

public class TownGraphManager implements TownGraphManagerInterface {
	Graph graph = new Graph();

	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
		if (graph.containsEdge(new Town(town1), new Town(town2))) {
			return false;
		}
		graph.addEdge(new Town(town1), new Town(town2), weight, roadName);
		return true;
	}

	@Override
	public String getRoad(String town1, String town2) {
		return graph.getEdge(new Town(town1), new Town(town2)).getName();
	}

	@Override
	public boolean addTown(String v) {
		if (this.containsTown(v)) {
			return false;
		}
		graph.addVertex(new Town(v));
		return true;
	}

	@Override
	public boolean containsTown(String v) {
		if (graph.containsVertex(new Town(v))) {
			return true;
		}
		return false;
	}

	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		return graph.containsEdge(new Town(town1), new Town(town2));
	}

	@Override
	public ArrayList<String> allRoads() {
		ArrayList<String> roads = new ArrayList<String>();
		Set<Road> set = graph.edgeSet();
		for (Road x : set) {
			roads.add(x.getName());
		}
		roads.sort(Comparator.naturalOrder());
		return roads;
	}

	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		Road removed = graph.removeEdge(new Town(town1), new Town(town2), 0, road);
		return removed != null;
	}

	@Override
	public boolean deleteTown(String v) {
		return graph.removeVertex(new Town(v));
	}

	@Override
	public ArrayList<String> allTowns() {
		ArrayList<String> towns = new ArrayList<String>();
		Set<Town> set = graph.vertexSet();
		for (Town x : set) {
			towns.add(x.getName());
		}
		towns.sort(Comparator.naturalOrder());
		return towns;
	}

	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		Town t1 = null;
		Town t2 = null;
		Set<Town> set = graph.vertexSet();
		for (Town x : set) {
			if (x.getName().equals(town1)) {
				t1 = x;
			}
			if (x.getName().equals(town2)) {
				t2 = x;
			}
		}
		return graph.shortestPath(t1, t2);
	}

	public Town getTown(String town) {
		Town t1 = null;
		Set<Town> set = graph.vertexSet();
		for (Town x : set) {
			if (x.getName().equals(town)) {
				t1 = x;
			}
		}
		return t1;
	}

	public void populateTownGraph(File selectedFile) throws IOException, FileNotFoundException {
		Scanner sc = new Scanner(selectedFile);
		String line;
		String road;
		int weight;
		Town t1;
		Town t2;
		while (sc.hasNextLine()) {
			line = sc.nextLine();
			road = line.substring(0,line.indexOf(','));
			line = line.substring(line.indexOf(',') + 1);
			weight = Integer.parseInt(line.substring(0, line.indexOf(';')));
			line = line.substring(line.indexOf(';') + 1);
			t1 = new Town(line.substring(0, line.indexOf(';')));
			line = line.substring(line.indexOf(';') + 1);
			t2 = new Town(line);
			graph.addVertex(t1);
			graph.addVertex(t2);
			graph.addEdge(t1, t2, weight, road);
		}
		sc.close();
	}

}
