import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

public class Graph implements GraphInterface<Town, Road> {
	private Town[] vertexArray = new Town[100];
	private Road[][] adjacencyMatrix = new Road[100][100];
	private int size = 0;

	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {
		for (int i = 0; i < size; i++) {
			if (vertexArray[i] != null) {
				if (vertexArray[i].equals(sourceVertex)) {
					for (int j = 0; j < size; j++) {
						if (vertexArray[j] != null) {
							if (vertexArray[j].equals(destinationVertex)) {
								return adjacencyMatrix[i][j];
							}
						}
					}
				}
			}
		}
		return null;
	}

	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road r = new Road(sourceVertex, destinationVertex, weight, description);
		for (int i = 0; i < size; i++) {
			if (vertexArray[i] != null) {
				if (vertexArray[i].equals(sourceVertex)) {
					for (int j = 0; j < size; j++) {
						if (vertexArray[j] != null) {
							if (vertexArray[j].equals(destinationVertex)) {
								adjacencyMatrix[i][j] = r;
								adjacencyMatrix[j][i] = r;
							}
						}
					}
				}
			}
		}
		return r;
	}

	@Override
	public boolean addVertex(Town v) {
		if (size < 100 && !containsVertex(v)) {
			vertexArray[size] = v;
			size++;
			return true;
		}
		return false;

	}

	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) {
		if (getEdge(sourceVertex, destinationVertex) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean containsVertex(Town v) {
		for (int i = 0; i < size; i++) {
			if (vertexArray[i] != null) {
				if (vertexArray[i].equals(v)) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public Set<Road> edgeSet() {
		Set<Road> roadSet = new HashSet<Road>();
		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 100; j++) {
				if (adjacencyMatrix[i][j] != null) {
					roadSet.add(adjacencyMatrix[i][j]);
				}
			}
		}
		return roadSet;
	}

	@Override
	public Set<Road> edgesOf(Town vertex) {
		Set<Road> roadSet = new HashSet<Road>();
		int v = -1;
		for (int i = 0; i < 100; i++) {
			if (vertexArray[i] != null) {
				if (vertexArray[i].equals(vertex)) {
					v = i;
					break;
				}
			}
		}
		if (v != -1) {
			for (int j = 0; j < 100; j++) {
				if (adjacencyMatrix[v][j] != null) {
					roadSet.add(adjacencyMatrix[v][j]);
				}
			}
		}
		return roadSet;
	}

	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {
		Road remove = null;
		for (int i = 0; i < size; i++) {
			if (vertexArray[i].equals(sourceVertex)) {
				for (int j = 0; j < size; j++) {
					if (vertexArray[j].equals(destinationVertex)) {
						remove = adjacencyMatrix[i][j];
						adjacencyMatrix[i][j] = null;
						adjacencyMatrix[j][i] = null;
					}
				}
			}
		}
		return remove;
	}

	@Override
	public boolean removeVertex(Town v) {
		int vertex = -1;
		boolean r = false;
		for (int i = 0; i < 100; i++) {
			if (vertexArray[i] == null) {
				continue;
			}
			if (vertexArray[i].equals(v)) {
				vertexArray[i] = null;
				vertex = i;
				r = true;
			}
		}
		if (vertex != -1) {
			for (int j = 0; j < 100; j++) {
				adjacencyMatrix[j][vertex] = null;
				adjacencyMatrix[vertex][j] = null;
			}
		}
		return r;

	}

	@Override
	public Set<Town> vertexSet() {
		Set<Town> set = new HashSet<>();
		for (int i = 0; i < size; i++) {
			if (vertexArray[i] != null) {
				set.add(vertexArray[i]);
			}
		}
		return set;
	}

	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {
		dijkstraShortestPath(sourceVertex);
		ArrayList<String> path = new ArrayList<>();
		Town current = destinationVertex;
		while (current != null && !current.equals(sourceVertex)) {
			Town previous = current.getBackPath();
			if (previous == null)
				break;
			int s = -1, d = -1;
			for (int i = 0; i < size; i++) {
				if (vertexArray[i] != null) {
					if (vertexArray[i].equals(previous)) {
						s = i;
					}
					if (vertexArray[i].equals(current)) {
						d = i;
					}
				}
			}
			Road r = adjacencyMatrix[s][d];
			path.add(0, previous.getName() + " via " + r.getName() + " to " + current.getName() + " " + r.getWeight()
					+ " mi");
			current = previous;
		}
		return path;
	}

	@Override
	public void dijkstraShortestPath(Town startVertex) {
		int noEdge = 0;
		int noPath = Integer.MAX_VALUE;
		int[] minPathLengths = new int[size];
		boolean[] verticesIncluded = new boolean[size];
		Road[][] spt = new Road[size][size];
		int[][] aCopy = new int[size][size];
		for (int i = 0; i < size; i++) {
			minPathLengths[i] = noPath;
			verticesIncluded[i] = false;
			for (int j = 0; j < size; j++) {
				spt[i][j] = null;
				if (adjacencyMatrix[i][j] == null) {
					aCopy[i][j] = noEdge;
				} else {
					aCopy[i][j] = adjacencyMatrix[i][j].getWeight();
				}
			}
		}
		int startIndex = -1;
		for (int i = 0; i < size; i++) {
			if (vertexArray[i].equals(startVertex)) {
				startIndex = i;
				break;
			}
		}
		minPathLengths[startIndex] = 0;
		startVertex.setMinWt(0);
		startVertex.setBackPath(null);
		for (int count = 0; count < size - 1; count++) {
			int rowMin = -1;
			int minPath = noPath;
			for (int i = 0; i < size; i++) {
				if (!verticesIncluded[i] && minPathLengths[i] < minPath) {
					minPath = minPathLengths[i];
					rowMin = i;
				}
			}
			if (rowMin == -1) {
				break;
			}
			verticesIncluded[rowMin] = true;
			for (int colMin = 0; colMin < size; colMin++) {
				if (!verticesIncluded[colMin] && aCopy[rowMin][colMin] != noEdge && minPathLengths[rowMin] != noPath) {
					int newPath = minPathLengths[rowMin] + aCopy[rowMin][colMin];
					if (newPath < minPathLengths[colMin]) {
						minPathLengths[colMin] = newPath;
						vertexArray[colMin].setMinWt(newPath);
						vertexArray[colMin].setBackPath(vertexArray[rowMin]);
						spt[rowMin][colMin] = adjacencyMatrix[rowMin][colMin];
						spt[colMin][rowMin] = adjacencyMatrix[rowMin][colMin];
					}
				}
			}
		}
	}
}
