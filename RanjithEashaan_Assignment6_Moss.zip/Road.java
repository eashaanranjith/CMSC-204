
public class Road implements Comparable<Road> {
	private Town source;
	private Town destination;
	private int degrees;
	private String name;

	public Road(Town source, Town destination, String name) {
		this.source = source;
		this.destination = destination;
		this.name = name;
	}

	public Road(Town source, Town destination, int degrees, String name) {
		this(source, destination, name);
		this.degrees = degrees;
	}

	public void setSource(Town source) {
		this.source = source;
	}

	public void setDestination(Town destination) {
		this.destination = destination;
	}

	public void setDegrees(int degrees) {
		this.degrees = degrees;
	}

	public void setName(String name) {
		this.name = name;
		;
	}

	public Town getSource() {
		return source;
	}

	public Town getDestination() {
		return destination;
	}

	public int getWeight() {
		return degrees;
	}

	public String getName() {
		return name;
	}

	@Override
	public int compareTo(Road o) {
		return this.name.compareTo(o.getName());
	}

	public boolean contains(Town town) {
		if (source.equals(town) || destination.equals(town)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String toString() {
		return name + " " + degrees + " " + source.getName() + " " + destination.getName();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Road o = (Road) obj;
		return this.contains(o.source) && this.contains(o.destination);
	}

}
