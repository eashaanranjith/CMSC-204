import java.util.Set;
import java.util.HashSet;

public class Town implements Comparable<Town> {
	private String name;
	private Set<Town> adjacent;
	private int weight;
	private Town backPath;
	private int minWeight;

	public Town(String name) {
		this.name = name;
	}

	public Town(Town templateTown) {
		this(templateTown.getName());
		this.adjacent = new HashSet(templateTown.getAdjacent());
		this.weight = templateTown.getWt();
		this.backPath = templateTown.getBackPath();
	}

	public void addAdjTown(Town o) {
		adjacent.add(o);
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setWt(int weight) {
		this.weight = weight;
	}

	public void setBackPath(Town backPath) {
		this.backPath = backPath;
	}

	public void setMinWt(int minWeight) {
		this.minWeight = minWeight;
	}

	public String getName() {
		return name;
	}

	public Set<Town> getAdjacent() {
		return adjacent;
	}

	public int getWt() {
		return weight;
	}

	public Town getBackPath() {
		return backPath;
	}

	public int getMinWtToSource(Town sourceVertex) {
		return minWeight;
	}

	@Override
	public int compareTo(Town o) {
		return this.name.compareTo(o.getName());
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Town x : adjacent) {
			sb.append(x.getName() + " ");
		}
		return sb.toString().trim();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Town o = (Town) obj;
		return name.equals(o.getName());
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

}
